package com.example.username.easyhome;

/**
 * Created by username on 5/5/18.
 */

public class Profile {
    private String name;
    private String phn;
    private String address;


}
